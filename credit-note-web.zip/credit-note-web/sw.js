/* 빌드 때 버전과 전체 정적 자료 목록을 넣습니다. 학습 기록은 이 캐시와 별도로 보관합니다. */
const VERSION = '54d171f26b203161';
const CACHE_PREFIX = 'credit-note-pwa-';
const CACHE_NAME = CACHE_PREFIX + VERSION;
const FILES = ["./_expo/static/js/web/index-b0fe116b53aa3457077132007bb163de.js","./assets/assets/assessments/exam-1-answers-1.03f0ee90d709e754092a5bdd368acedd.png","./assets/assets/assessments/exam-1-answers-2.5a41dcfa84b3383f40311e0dacaeface.png","./assets/assets/assessments/exam-1-answers-3.912d1248536a1868afe8bd41091d644f.png","./assets/assets/assessments/exam-1-answers-4.7f9a13f64ce9078c02a39a85226a8555.png","./assets/assets/assessments/exam-1-questions-1.151996697f871a6a0693a5315878d62f.png","./assets/assets/assessments/exam-1-questions-2.e5ebe3f17701da0ffe0f5b2eac8c6544.png","./assets/assets/assessments/exam-1-questions-3.e484184556d8b777f5ae809e769d7aea.png","./assets/assets/assessments/exam-1-questions-4.4b75dcbebd198789edadc1068a98f036.png","./assets/assets/assessments/exam-2-answers-1.f504150581b95a2e017153e4acf21711.png","./assets/assets/assessments/exam-2-answers-2.8673fa6fa7c32c0f78f7e3dd284ad263.png","./assets/assets/assessments/exam-2-answers-3.24cc5557078c7f3aae91229079879ae7.png","./assets/assets/assessments/exam-2-questions-1.4d2aaa0441f4a5fe51bd094231f80eee.png","./assets/assets/assessments/exam-2-questions-2.c9cec578356a65e4ad614ce368375fab.png","./assets/assets/assessments/exam-2-questions-3.0121299edee1238a18b88a076e26c819.png","./assets/assets/assessments/exam-2-questions-4.e8ef4e10e2166f03b3b11a4d53012f7d.png","./assets/assets/assessments/exam-3-answers-1.2fcc7d232fea7c69d78222a3ab2086f4.png","./assets/assets/assessments/exam-3-answers-2.116a7686c5a86df1e56e880c85cf7454.png","./assets/assets/assessments/exam-3-answers-3.333904e53863f30381c40a580c3214b0.png","./assets/assets/assessments/exam-3-questions-1.76a15c49a08e02ea9c3ed5031daf0be1.png","./assets/assets/assessments/exam-3-questions-2.9f4be569ec7c2ef2496fab1898e6ba80.png","./assets/assets/assessments/exam-3-questions-3.d1867f0a16f375fcb49c6ce22620e9da.png","./assets/assets/assessments/exam-3-questions-4.e2a065c0cbb2baa306f2ac938c0b0dac.png","./favicon.ico","./icons/icon-180.png","./icons/icon-192.png","./icons/icon-512.png","./index.html","./manifest.webmanifest","./metadata.json"];
const INTEGRITY = ["sha256-d+OUylrAPmYPXBxiUFCWZ3Dh/PY97B8fB0tbcdTMNfk=","sha256-vahZXAbVgCtdGy1p6OAG59iUwzTcViFGXUsNP6sw1RU=","sha256-2TvwXGi1/PF21DUHtg3RETVmpNWqv/XiWxztUhQ0+m8=","sha256-CD3sF9Pp/rTttde+A4vRHBj2IpBKVFEwUw4TYXcAkU8=","sha256-xj/gzL5L3ur1dj5UQLUbTZ7sUgcIw2/H7pmQ+8OOzB4=","sha256-R8jicU02zzStYU2VGSRvc8p7o3GUA4EIiPRgFT7EM6o=","sha256-9ZLiT9WjMDS2msEafqUhofIWjGtqo6xCo2g/OtgXEqo=","sha256-D/c4sHlFheRy+HwHgo34cLQRgXkYkpt3EZZvy3zpQnI=","sha256-pSTckkX6dIIPkUh9l96PywTEvU1WEe3XVXItpeBfPuk=","sha256-AbbVD+hB3jsyN/6oOjuDWfiz+lW7PcWfj/7c0Ox3mto=","sha256-desckfmseo4B0OTvVDkepu+GfnGiYHNAydknKEiBWiI=","sha256-pX8hpdO0JzwNhihfNDVQM1Rac7/D+OMcxL1MMPiYKpY=","sha256-pFxP2UVtvtmGJ/bL3AAHwAogOC/hWXSRG/FYuNfCSGM=","sha256-vMCp8P1qVULK5rAd2hxrD9FGmXo5zENSqDTq/lsZRfM=","sha256-ATJRC8VNrZDD0Fbt7hbX1uBes7DULfmcD3hNQYPq/VA=","sha256-IXJgpmlMFF4Yf8cZucJLkfZK+geEb4si7OzcoJfDvfY=","sha256-z5hustnWMn9kb2nMpjJwex2qXYqliGQQJH801H3qGUs=","sha256-5J/ht/XV0Dvam7h4mjq6Mail5CvQORueX0/Is51Wo8o=","sha256-Uiz5GDWrgCD9sBb6EDQYYHCdocGvrztBoglbfWJeIqs=","sha256-7pdjqI/l6Rl/IOqTSABKD+DCxmBsXnRcmplEhOH2uFc=","sha256-uqzXcscWkS6yFKjHgHf7IKg9Krq2eAv+hiTIRWp7aq4=","sha256-gp8CwOW2fTBgN5tkDaLWnwoq1E/Aty95BnN8U+EDv/o=","sha256-XcWvD0mAT6kUlheisdKEACANaqs7jQRIRWQd2OU2sks=","sha256-HFeOWjNE6pWZCqVlVFf7xEWX/Vn3oemFPIGJiuoqWvM=","sha256-Q6Ni3E2Avno36tlmtxoFOe17WKhCy5eD4s38I8kALH8=","sha256-O+M+P2+OfEc7+DTlup/i+SXZj2eFy1zIMKoPoyi+LlA=","sha256-e7YMlR5Kr+n7A1bY2+eIwpaNeWi8Bp+ZL3nPdSwRP/A=","sha256-w3ABAQD1eK3A5fCMk6IdoqrwnXaZ7ppBnLFVis+53hQ=","sha256-5v3D2x1587uZoP9bQT0dmxxZ3K/y6gxaVpMsdGMMF2I=","sha256-ql8ZzITUHA+McOzssryC6GMifqHhIWMqyoeethYFaZE="];
const urls = FILES.map(path => new URL(path, self.registration.scope).href);

async function fillCache() {
  const cache = await caches.open(CACHE_NAME);
  // 새 배포의 HTML과 이전 코드가 섞이거나 누락된 에셋 대신 오류 페이지가 저장되지 않게 확인합니다.
  await cache.addAll(urls.map((url, index) => new Request(url, { cache: 'reload', integrity: INTEGRITY[index] })));
}
async function offlineStatus() {
  const cache = await caches.open(CACHE_NAME);
  const present = await Promise.all(urls.map(url => cache.match(url)));
  return { version: VERSION, ready: present.every(Boolean), count: present.filter(Boolean).length, total: urls.length };
}
self.addEventListener('install', event => {
  // 새 버전은 사용자가 적용할 때까지 기다립니다. 문제 풀이 도중 강제 새로고침하지 않습니다.
  event.waitUntil(fillCache().catch(async error => { await caches.delete(CACHE_NAME); throw error; }));
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = (await caches.keys()).filter(name => name.startsWith(CACHE_PREFIX));
    // 이미 열려 있는 이전 버전 화면의 원문 에셋도 계속 읽을 수 있게 직전 캐시를 남깁니다.
    const previous = names.filter(name => name !== CACHE_NAME).slice(-1)[0];
    await Promise.all(names.filter(name => name !== CACHE_NAME && name !== previous).map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});
self.addEventListener('message', event => {
  if (event.data?.type === 'SKIP_WAITING') event.waitUntil(self.skipWaiting());
  if (event.data?.type === 'OFFLINE_STATUS') event.waitUntil(offlineStatus().then(status => event.ports[0]?.postMessage(status)));
  if (event.data?.type === 'REPAIR_CACHE') event.waitUntil((async () => {
    try { await fillCache(); event.ports[0]?.postMessage(await offlineStatus()); }
    catch { event.ports[0]?.postMessage({ ready: false, error: '자료 저장에 실패했습니다.' }); }
  })());
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== self.location.origin) return;
  event.respondWith((async () => {
    const current = await caches.open(CACHE_NAME);
    if (event.request.mode === 'navigate') {
      // HTML과 코드 버전이 서로 섞이지 않도록 활성 버전의 앱 화면을 함께 제공합니다.
      const shell = await current.match(new URL('./index.html', self.registration.scope).href);
      if (shell) return shell;
      return fetch(event.request);
    }
    const cached = await current.match(event.request);
    if (cached) return cached;
    const names = (await caches.keys()).filter(name => name.startsWith(CACHE_PREFIX) && name !== CACHE_NAME);
    for (const name of names.reverse()) {
      const old = await (await caches.open(name)).match(event.request);
      if (old) return old;
    }
    return fetch(event.request);
  })());
});
